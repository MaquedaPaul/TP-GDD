Curso: K3521
Número de grupo: 34
Nombre y legajo de integrantes:
Daniel Aizcorbe - 1727898  (del curso K3572)
Pablo Maqueda   - 1762620
Los otros miembros dejaron la materia

Email del responsable del grupo: pmaqueda@frba.utn.edu.ar
