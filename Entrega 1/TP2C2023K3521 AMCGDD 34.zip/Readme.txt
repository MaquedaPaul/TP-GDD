Curso: K3521
Número de grupo: 34
Nombre y legajo de integrantes:
Daniel Aizcorbe - 1727898  (del curso K3572)
Nicole Chavez   - 1745633
Pablo Maqueda   - 1762620
Martin Ibarra   - 1681588

Email del responsable del grupo: pmaqueda@frba.utn.edu.ar
